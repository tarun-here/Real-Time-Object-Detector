# Detection-home > 2024-09-01 1:44pm
https://universe.roboflow.com/nothing-k62bf/detection-home

Provided by a Roboflow user
License: CC BY 4.0

